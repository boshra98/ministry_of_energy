import {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger
} from "./chunk-F76MWTA6.js";
import "./chunk-55RMXE6S.js";
import "./chunk-LOWN7NJC.js";
import {
  MatOptgroup,
  MatOption
} from "./chunk-555PKYYZ.js";
import "./chunk-6OQOIUKJ.js";
import "./chunk-XLBB234S.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-QSXTUITT.js";
import "./chunk-QVTC2G64.js";
import "./chunk-XA3EVXH3.js";
import "./chunk-XKWKVDRT.js";
import "./chunk-6TG5Z3WK.js";
import "./chunk-NT5MW7P4.js";
import "./chunk-KDE6KJMJ.js";
import "./chunk-HDODZT3I.js";
import "./chunk-3LHBDT7T.js";
import "./chunk-FD4RI3RN.js";
import "./chunk-MZVJP6II.js";
import "./chunk-CMMK4I6M.js";
import "./chunk-NTIPJEPN.js";
import "./chunk-LL5OSLF4.js";
import "./chunk-FJG6LBTU.js";
import "./chunk-VENV3F3G.js";
import "./chunk-VD3VXMNQ.js";
import "./chunk-GWFLKVBH.js";
import "./chunk-7BOTEGCF.js";
import "./chunk-S4T4Y7A5.js";
import "./chunk-R4F6ANYX.js";
import "./chunk-7UJZXIJQ.js";
import "./chunk-7SVHHABW.js";
import "./chunk-PCINYOXX.js";
import "./chunk-MXMNHR4D.js";
import "./chunk-PPTBGCDQ.js";
import "./chunk-EWWQGRUQ.js";
import "./chunk-UUVERCPC.js";
import "./chunk-JRFR6BLO.js";
import "./chunk-HWYXSU2G.js";
import "./chunk-MARUHEWW.js";
import "./chunk-3OV72XIM.js";

// node_modules/@angular/material/fesm2022/select.mjs
var matSelectAnimations = {
  // Represents
  // trigger('transformPanel', [
  //   state(
  //     'void',
  //     style({
  //       opacity: 0,
  //       transform: 'scale(1, 0.8)',
  //     }),
  //   ),
  //   transition(
  //     'void => showing',
  //     animate(
  //       '120ms cubic-bezier(0, 0, 0.2, 1)',
  //       style({
  //         opacity: 1,
  //         transform: 'scale(1, 1)',
  //       }),
  //     ),
  //   ),
  //   transition('* => void', animate('100ms linear', style({opacity: 0}))),
  // ])
  /** This animation transforms the select's overlay panel on and off the page. */
  transformPanel: {
    type: 7,
    name: "transformPanel",
    definitions: [
      {
        type: 0,
        name: "void",
        styles: {
          type: 6,
          styles: { opacity: 0, transform: "scale(1, 0.8)" },
          offset: null
        }
      },
      {
        type: 1,
        expr: "void => showing",
        animation: {
          type: 4,
          styles: {
            type: 6,
            styles: { opacity: 1, transform: "scale(1, 1)" },
            offset: null
          },
          timings: "120ms cubic-bezier(0, 0, 0.2, 1)"
        },
        options: null
      },
      {
        type: 1,
        expr: "* => void",
        animation: {
          type: 4,
          styles: { type: 6, styles: { opacity: 0 }, offset: null },
          timings: "100ms linear"
        },
        options: null
      }
    ],
    options: {}
  }
};
export {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatOptgroup,
  MatOption,
  MatPrefix,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  MatSuffix,
  matSelectAnimations
};
//# sourceMappingURL=@angular_material_select.js.map
