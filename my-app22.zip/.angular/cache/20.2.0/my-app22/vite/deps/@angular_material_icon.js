import {
  ICON_REGISTRY_PROVIDER,
  ICON_REGISTRY_PROVIDER_FACTORY,
  MAT_ICON_DEFAULT_OPTIONS,
  MAT_ICON_LOCATION,
  MAT_ICON_LOCATION_FACTORY,
  MatIcon,
  MatIconModule,
  MatIconRegistry,
  getMatIconFailedToSanitizeLiteralError,
  getMatIconFailedToSanitizeUrlError,
  getMatIconNameNotFoundError,
  getMatIconNoHttpProviderError
} from "./chunk-6TTEI4KN.js";
import "./chunk-73D4ATBC.js";
import "./chunk-AUKT2SPL.js";
import "./chunk-7BOTEGCF.js";
import "./chunk-S4T4Y7A5.js";
import "./chunk-R4F6ANYX.js";
import "./chunk-7SVHHABW.js";
import "./chunk-PCINYOXX.js";
import "./chunk-MXMNHR4D.js";
import "./chunk-PPTBGCDQ.js";
import "./chunk-EWWQGRUQ.js";
import "./chunk-UUVERCPC.js";
import "./chunk-JRFR6BLO.js";
import "./chunk-HWYXSU2G.js";
import "./chunk-MARUHEWW.js";
import "./chunk-3OV72XIM.js";
export {
  ICON_REGISTRY_PROVIDER,
  ICON_REGISTRY_PROVIDER_FACTORY,
  MAT_ICON_DEFAULT_OPTIONS,
  MAT_ICON_LOCATION,
  MAT_ICON_LOCATION_FACTORY,
  MatIcon,
  MatIconModule,
  MatIconRegistry,
  getMatIconFailedToSanitizeLiteralError,
  getMatIconFailedToSanitizeUrlError,
  getMatIconNameNotFoundError,
  getMatIconNoHttpProviderError
};
